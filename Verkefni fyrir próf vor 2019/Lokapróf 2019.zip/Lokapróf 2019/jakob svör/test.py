import django

print(django.get_version())